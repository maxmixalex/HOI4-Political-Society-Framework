version="0.4.0"
tags={ "Gameplay" "Alternative History" }
name="Political Society Framework"
path="mod/psf"
