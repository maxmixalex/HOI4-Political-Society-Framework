version="0.4.0"
tags={ "Gameplay" "Alternative History" }
name="PSF — Vanilla Political Societies"
dependencies={ "Political Society Framework" }
path="mod/psf_vanilla_example"
