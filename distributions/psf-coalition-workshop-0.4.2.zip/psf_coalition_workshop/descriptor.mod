version="0.4.2"
tags={ "Gameplay" "Alternative History" }
name="PSF Coalition Workshop"
dependencies={ "Political Society Framework" }
