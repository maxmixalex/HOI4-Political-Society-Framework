# Political Society Framework 0.1.0

## 安装

将 `psf`、`psf_vanilla_example` 两个目录，以及 `psf.mod`、`psf_vanilla_example.mod` 两个文件，放入 HOI4 用户资料目录中的 `mod` 文件夹。

- Windows 通常为 `文档/Paradox Interactive/Hearts of Iron IV/mod`。
- Linux 通常为 `~/.local/share/Paradox Interactive/Hearts of Iron IV/mod`。
- macOS 通常为 `~/Documents/Paradox Interactive/Hearts of Iron IV/mod`。

在启动器的同一游玩集中同时启用 **Political Society Framework** 和 **PSF — Vanilla Political Societies**。本版本请开始新战役。
打开本国政治面板或其他国家的外交面板，即可查看国家总览、政治团体、政治光谱与联盟。选中本国团体后，决议面板提供对应政治行动。

此包按提供的原版界面脚本构建。会同时替换政治、外交或选国界面文件的其他模组需要合并适配。`supported_version=1.*` 是启动器匹配范围，并不代表所有旧版本均已验证。
已完成 Schema、行为回归、界面结构和真实 cwtools 校验；尚未在实际 HOI4 引擎中运行验收。

## Installation

Copy both mod folders and both `.mod` launcher files to your HOI4 user-data `mod` directory. Enable the framework and the dependent content pack together and start a new campaign.
Open politics or diplomacy to inspect societies. Select a domestic organization for its actions in the decisions panel.
The native interface overrides need compatibility work with other UI overhauls. Static/script checks do not replace an in-game launch test.

Source and authoring documentation: https://github.com/maxmixalex/HOI4-Political-Society-Framework

`psf-registry.json` lists the compiled APIs and stable IDs. `build-manifest.json` records generated-file hashes. The per-mod notices retain original-work and third-party attribution.
