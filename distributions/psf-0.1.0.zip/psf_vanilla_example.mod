version="0.1.0"
tags={ "Gameplay" "Alternative History" }
name="PSF — Vanilla Political Societies"
supported_version="1.*"
dependencies={ "Political Society Framework" }
path="mod/psf_vanilla_example"
