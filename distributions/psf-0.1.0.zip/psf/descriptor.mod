version="0.1.0"
tags={ "Gameplay" "Alternative History" }
name="Political Society Framework"
supported_version="1.*"
