version="0.4.1"
tags={ "Gameplay" "Alternative History" }
name="Political Society Framework"
path="mod/psf"
