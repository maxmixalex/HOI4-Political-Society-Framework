# Political Society Framework 0.4.1

## 安装

将 `psf`、`psf_vanilla_example` 两个目录，以及 `psf.mod`、`psf_vanilla_example.mod` 两个文件，放入 HOI4 用户资料目录中的 `mod` 文件夹。

- Windows 通常为 `文档/Paradox Interactive/Hearts of Iron IV/mod`。
- Linux 通常为 `~/.local/share/Paradox Interactive/Hearts of Iron IV/mod`。
- macOS 通常为 `~/Documents/Paradox Interactive/Hearts of Iron IV/mod`。

在启动器的同一游玩集中同时启用 **Political Society Framework** 和 **PSF — Vanilla Political Societies**。本版本请开始新战役。
从旧版升级时，先移走旧的 `psf/` 与 `psf_vanilla_example/` 两个目录，再复制本包；不要只把新文件覆盖到旧目录上，否则旧的 GUI 分块可能继续被游戏加载。保留其他模组目录。
打开本国政治面板或其他国家的外交面板，即可查看国家总览、政治团体、政治光谱与联盟。选中本国团体后，决议面板提供对应政治行动。

此包按提供的原版界面脚本构建。会同时替换政治、外交或选国界面文件的其他模组需要合并适配。原版脚本快照没有提供可核实的游戏版本号；默认省略可选的 `supported_version`，作者可在编译时显式指定本机目标版本。
已完成 Schema、行为回归、界面结构和真实 cwtools 校验；尚未在实际 HOI4 引擎中运行验收。

## Installation

Copy both mod folders and both `.mod` launcher files to your HOI4 user-data `mod` directory. Enable the framework and the dependent content pack together and start a new campaign.
When upgrading, move the old `psf/` and `psf_vanilla_example/` folders aside before copying the new folders. Overlaying files can leave obsolete GUI chunks loaded alongside this version; leave unrelated mods in place.
Open politics or diplomacy to inspect societies. Select a domestic organization for its actions in the decisions panel.
The native interface overrides need compatibility work with other UI overhauls. Static/script checks do not replace an in-game launch test.

Source and authoring documentation: https://github.com/maxmixalex/HOI4-Political-Society-Framework

`psf-registry.json` lists the compiled APIs and stable IDs. `build-manifest.json` records generated-file hashes. The per-mod notices retain original-work and third-party attribution.
