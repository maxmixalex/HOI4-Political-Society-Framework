version="0.4.1"
tags={ "Gameplay" "Alternative History" }
name="PSF — Vanilla Political Societies"
dependencies={ "Political Society Framework" }
