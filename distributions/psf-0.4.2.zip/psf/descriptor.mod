version="0.4.2"
tags={ "Gameplay" "Alternative History" }
name="Political Society Framework"
