version="0.3.1"
tags={ "Gameplay" "Alternative History" }
name="Political Society Framework"
path="mod/psf"
