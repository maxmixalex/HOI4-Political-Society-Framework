version="0.2.0"
tags={ "Gameplay" "Alternative History" }
name="PSF — Vanilla Political Societies"
dependencies={ "Political Society Framework" }
