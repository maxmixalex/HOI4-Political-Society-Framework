version="0.2.0"
tags={ "Gameplay" "Alternative History" }
name="Political Society Framework"
path="mod/psf"
